var http = require('http');
var server = http.createServer(function(req,res){
    var opcao = http.url;    
})
localHost:3000/cursos
alguma coisa assim....